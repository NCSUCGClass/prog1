# prog1-2018-shell
This repo branch contains the shell for program 1 from cg class 2018 at nc state (ray tracing triangles). 

It currently contains the 2017 shell, and needs to be improved.
